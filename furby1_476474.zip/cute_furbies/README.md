# Cute Furbies
Minetest Furbies Mod
![Screenshot](screenshot.png)
