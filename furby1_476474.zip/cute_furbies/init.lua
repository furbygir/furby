minetest.register_node('cute_furbies:furby', {
	description = 'Purple Furby',
	drawtype = 'mesh',
	mesh = 'cute_furby.obj',
	tiles = {'cute_furby.png'},
	inventory_image = 'cute_furby.png',
	groups = {oddly_breakable_by_hand=2},
	paramtype = 'light',
	paramtype2 = 'facedir',
	selection_box = {
		type = 'fixed',
		fixed = {-.5, -.5, -.5, .5, .5, .5},63
		},	
	collision_box = {
		type = 'fixed',
		fixed = {-.5, -.5, -.5, .5, .5, .5},
		},
})

minetest.register_node('cute_furbies:furby_blue', {
	description = 'cute Furby boom Blue waves',
	drawtype = 'mesh',
	mesh = 'cute_furby_white.obj',
	tiles = {'cute_furby_colors.png', 'cute_furby_body.png'},
	inventory_image = 'cute_furby_colors.png',
	groups = {oddly_breakable_by_hand=2},
	walkable = false,
	paramtype = 'light',
	paramtype2 = 'facedir',
	selection_box = {
		type = 'fixed',
		fixed = {-.5, -.5, -.5, .5, .5, .5},63
		},	
	collision_box = {
		type = 'fixed',
		fixed = {-.5, -.5, -.5, .5, .5, .5},
		}
})

minetest.register_craft({
	output = "moms_furby:furby_blue",
	recipe = {
		{ "wool:cyan", "wool:blue", "wool:cyan" },
		{ "wool:blue", "default:mese", "wool:blue" },
		{ "wool:cyan", "wool:blue", "wool:cyan" }
	}
})